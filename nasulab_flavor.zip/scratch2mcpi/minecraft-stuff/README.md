-------------------------------------------------------------------------------
Minecraft - Stuff Library
Martin O'Hanlon (martin@ohanlonweb.com)
http://www.stuffaboutcode.com
-------------------------------------------------------------------------------

An extension library of useful 'stuff' (aka classes) I have created for 
Minecraft: Pi Edition's API.  It provides functions for drawing lines
and other objects

------------------------------------------------------------------------------

Version history
0.1 - first beta release, MinecraftDrawing class
0.2 - extended with new drawing functions and MinecraftShapes class

-------------------------------------------------------------------------------
