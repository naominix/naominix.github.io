#!/bin/bash
cd /home/pi/MineTools/indiecity/InstalledApps/minetools/Full
./minetools.py

