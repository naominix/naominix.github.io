Michelle's Minetools
By Jeff & Michelle Ledger

Requirements: Prior install of minecraft-pi before running this program.

This program provides a simple interface to tiles and controls
hidden in minecraft-pi.

Start:
======

Step 1) Launch minecraft-pi and load a world.
Step 2) Press TAB to change windows.
Step 3) Launch minetools.py

Controls:
=========

Water and Water Stationary Blocks (blue icon & blue icon "S") appear below feet.

Lava and Lava Stationary Blocks (lava icon & lava icon "S") appear below feet.

Erase block (blue square) erases blow below feet.

Arrow buttons move right/left/forward/backward/up/down in single increments.

10/10 and 20/20 shovel icon removes 10/10 or 20/20 blocks below feet.

Red/Blue tacks bookmark position. (during session)

Red/Blue pinpoints move to bookmarked position. (during session)

Fixed camera icon places camera / Eye icon restores standard camera.

S1, S2, S3, S4 icons invoke script1.py, script2.py, script3.py, script4.py

LC and SC buttons save & load session.

Use keyboard arrow keys to select tile "BlockID".  Use hammer icon to place.

Right clicking many tiles will change their state/color.

Right/Left clicking TNT blocks will cause them to explode.

Bomb and Storm icons place random lava and water blocks.
