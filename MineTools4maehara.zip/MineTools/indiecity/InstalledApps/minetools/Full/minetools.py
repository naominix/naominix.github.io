#!/usr/bin/python
"""
 Michelle's MineTools 1.1
 Written by Michelle Ledger & Jeff Ledger
 http://www.ledgerlabs.us/raspberrypi
"""
import pygame
import os

# Open Pygame Window
x = 100
y = 0
os.environ['SDL_VIDEO_WINDOW_POS'] = "%d,%d" % (x,y)
size = (500, 100)
screen = pygame.display.set_mode(size)
BLACK = ( 0, 0, 0)
WHITE = ( 255, 255, 255)
pygame.init()
pygame.display.set_caption("Michelle's MineTools")
clock = pygame.time.Clock()

# Check to see if minecraft-pi python scripts are present.
# Provide somewhat friendly error if minecraft api isn't found.
#minc = os.getenv("HOME")+'/mcpi/api/python/mcpi'
minc = '/opt/minecraft-pi/api/python/mcpi'
picraft = os.path.isdir(minc)

font = pygame.font.Font(None, 25)
while not picraft:
   errormc = font.render("Minecraft Python Api Not Found!",True,WHITE)
   screen.blit(errormc,[10,10])
   expected = font.render("Expected in: ",True,WHITE)
   errormcc = font.render(minc,True,WHITE)
   errorc = font.render("Please correct and re-run.",True,WHITE)
   screen.blit(expected,[10,30])
   screen.blit(errormcc,[120,30])
   screen.blit(errorc,[10,50])
   clock.tick(3)
   pygame.display.flip()

   for event in pygame.event.get():
       if event.type == pygame.QUIT:
          os._exit(1)


# Required Minecraft-pi files are copied from ~/mcpi/api/python/mcpi

os.system("cp ~/mcpi/api/python/mcpi/* .")

# Make sure script1.py - script2.py are executable.
os.system("sudo chmod +x script1.py")
os.system("sudo chmod +x script2.py")
os.system("sudo chmod +x script3.py")
os.system("sudo chmod +x script4.py")

import minecraft
import block
import time
import random
import errno


# Detect if Minecraft-pi World is open and running.
try:
   mc = minecraft.Minecraft.create()
   mcworld = True

except:
   mcworld = False

while not mcworld:
   errormw = font.render("Minecraft World Not Detected!",True,WHITE)
   screen.blit(errormw,[10,10])
   expectw = font.render("Please start Minecraft, open world and re-run. ",True,WHITE)
   screen.blit(expectw,[10,30])
   clock.tick(3)
   pygame.display.flip()
   for event in pygame.event.get():
       if event.type == pygame.QUIT:
          os._exit(1)

# Minecraft-pi world detected!  Launch Michelle's Minetools!

mc.postToChat("MineTools Started...")
print ('Launching Minetools...')

KEYBLOCK= 0
xran=0
ytan=0

lava_image = pygame.image.load("lava.png").convert()
lavas_image = pygame.image.load("lava_s.png").convert()
water_image = pygame.image.load("water.png").convert()
waters_image = pygame.image.load("water_s.png").convert()
blank_image = pygame.image.load("blank.png").convert()
right_image = pygame.image.load("right_arrow.png").convert()
left_image = pygame.image.load("left_arrow.png").convert()
up_image = pygame.image.load("up_arrow.png").convert()
down_image = pygame.image.load("down_arrow.png").convert()
digten_image = pygame.image.load("shovel10_10.png").convert()
digtwenty_image = pygame.image.load("shovel20_20.png").convert()
bluetack_image = pygame.image.load("blue_tack.png").convert()
redtack_image = pygame.image.load("red_tack.png").convert()
bluedest_image = pygame.image.load("blue_dest.png").convert()
reddest_image = pygame.image.load("red_dest.png").convert()
fixedcam_image = pygame.image.load("fixed_camera.png").convert()
standardcam_image = pygame.image.load("standard_camera.png").convert()
script1_image = pygame.image.load("script1.png").convert()
script2_image = pygame.image.load("script2.png").convert()
script3_image = pygame.image.load("script3.png").convert()
script4_image = pygame.image.load("script4.png").convert()
load_image = pygame.image.load("load_checkpoint.png").convert()
save_image = pygame.image.load("save_checkpoint.png").convert()
build_image = pygame.image.load("build.png").convert()
bomb_image = pygame.image.load("bomb.png").convert()
flood_image = pygame.image.load("flood.png").convert()


w = screen.blit(water_image,[190,5])
ws = screen.blit(waters_image,[215,5])
l = screen.blit(lava_image,[240,5])
ls = screen.blit(lavas_image,[267,5])
bl = screen.blit(blank_image,[294,5])
forward = screen.blit(up_image,[50,35])
backward = screen.blit(down_image,[50,62])
left = screen.blit(left_image,[23,46])
right = screen.blit(right_image,[77,46])
up = screen.blit(up_image,[120,35])
down = screen.blit(down_image,[120,62])
digten = screen.blit(digten_image,[152,35])
digtwenty = screen.blit(digtwenty_image,[152,62])
redtack = screen.blit(redtack_image,[182,35])
reddest = screen.blit(reddest_image,[182,62])
bluetack = screen.blit(bluetack_image,[212,35])
bluedest = screen.blit(bluedest_image,[212,62])
fixedcam = screen.blit(fixedcam_image,[242,35])
standardcam = screen.blit(standardcam_image,[242,62])
script1 = screen.blit(script1_image,[272,35])
script2 = screen.blit(script2_image,[272,62])
script3 = screen.blit(script3_image,[302,35])
script4 = screen.blit(script4_image,[302,62])
load = screen.blit(load_image,[332,35])
save = screen.blit(save_image,[332,62])
build = screen.blit(build_image,[350,5])
bomb = screen.blit(bomb_image,[445,35])
flood = screen.blit(flood_image,[445,62])

done = False
blplayerpos = mc.player.getPos()
redplayerpos = mc.player.getPos()

while not done:
 
   hits = mc.events.pollBlockHits()

   for hit in hits:
            block = mc.getBlockWithData(hit.pos.x, hit.pos.y, hit.pos.z);
            block.data = (block.data + 1) & 0xf;
            mc.setBlock(hit.pos.x, hit.pos.y, hit.pos.z, block.id, block.data)

   for event in pygame.event.get():
       if event.type == pygame.QUIT: 
           done = True
 
       if event.type == pygame.KEYDOWN:
          if event.key == pygame.K_UP:
             KEYBLOCK += 1
          if event.key == pygame.K_RIGHT:
             KEYBLOCK += 10
          if event.key == pygame.K_DOWN:
             KEYBLOCK -= 1
          if event.key == pygame.K_LEFT:
             KEYBLOCK -= 10        

       if event.type == pygame.MOUSEBUTTONDOWN:
           pos = pygame.mouse.get_pos()
          
           if w.collidepoint(pos):
              print ('Set flowing water block under feet.')
              playerpos = mc.player.getTilePos()
              mc.setBlock(playerpos.x,playerpos.y-1,playerpos.z,8)
 
           if ws.collidepoint(pos):
              print ('Set stationary water block under feet.')
              playerpos = mc.player.getTilePos()
              mc.setBlock(playerpos.x,playerpos.y-1,playerpos.z,9)

           if l.collidepoint(pos):
              print ('Set flowing lava block under feet.')  
              playerpos = mc.player.getTilePos()
              mc.setBlock(playerpos.x,playerpos.y-1,playerpos.z,10)

           if ls.collidepoint(pos):
              print ('Set stationary lava block under feet.')
              playerpos = mc.player.getTilePos()
              mc.setBlock(playerpos.x,playerpos.y-1,playerpos.z,11)   

           if bl.collidepoint(pos):
              print ('Erase block under feet.')
              playerpos = mc.player.getTilePos()
              mc.setBlock(playerpos.x,playerpos.y-1,playerpos.z,0)

           if build.collidepoint(pos):
              print ('Build with block ID under feet.')
              playerpos = mc.player.getTilePos()
              mc.setBlock(playerpos.x,playerpos.y-1,playerpos.z,KEYBLOCK)

           if right.collidepoint(pos):
              print ('Move player 1 step right.')
              playerpos = mc.player.getPos()
              mc.player.setPos(playerpos.x+1,playerpos.y,playerpos.z)            

           if left.collidepoint(pos):
              print ('Move player 1 step left.')
              playerpos = mc.player.getPos()
              mc.player.setPos(playerpos.x-1,playerpos.y,playerpos.z)

           if forward.collidepoint(pos):
              print ('Move player 1 step forward.')
              playerpos = mc.player.getPos()
              mc.player.setPos(playerpos.x,playerpos.y,playerpos.z-1)

           if backward.collidepoint(pos):
              print ('Move player 1 step backward.')
              playerpos = mc.player.getPos()
              mc.player.setPos(playerpos.x,playerpos.y,playerpos.z+1)

           if up.collidepoint(pos):
              print ('Move player 1 step up.')
              playerpos = mc.player.getPos()
              mc.player.setPos(playerpos.x,playerpos.y+1,playerpos.z)

           if down.collidepoint(pos):
              print ('Move player 1 step down.')
              playerpos = mc.player.getPos()
              mc.player.setPos(playerpos.x,playerpos.y-1,playerpos.z)

           if digten.collidepoint(pos):
              print ('clear a 10 x 10 square.')
              playerpos = mc.player.getTilePos()
              for x in xrange(0,10):
                  for y in xrange(0,10):
                      mc.setBlock(playerpos.x-x,playerpos.y-1,playerpos.z+y,0)

           if digtwenty.collidepoint(pos):
              print ('clear a 20 x 20 square.')
              playerpos = mc.player.getTilePos()
              for x in xrange(0,20):
                  for y in xrange(0,20):
                      mc.setBlock(playerpos.x-x,playerpos.y-1,playerpos.z+y,0)
 
           if redtack.collidepoint(pos):
              print ('remember current red position.')
              mc.postToChat("Red Bookmark Set")
              redplayerpos = mc.player.getPos()

           if bluetack.collidepoint(pos):
              print ('remember current blue position.')
              mc.postToChat("Blue Bookmark Set")
              blplayerpos = mc.player.getPos()

           if reddest.collidepoint(pos):
              print ('goto red bookmarked position.')
              mc.player.setPos(redplayerpos.x,redplayerpos.y,redplayerpos.z)
           
           if bluedest.collidepoint(pos):
              print ('goto blue bookmarked position.')
              mc.player.setPos(blplayerpos.x,blplayerpos.y,blplayerpos.z)
          
           if fixedcam.collidepoint(pos):
              print ('place camera at current position.')
              mc.postToChat("Set fixed viewpoint.")
              playerpos = mc.player.getPos()
              mc.camera.setFixed()
              mc.camera.setPos(playerpos.x,playerpos.y,playerpos.z+2)

           if standardcam.collidepoint(pos):
              print ('place camera in standard position.')   
              mc.camera.setNormal(0)

           if script1.collidepoint(pos):
              print ('execute script1.py')
              os.system("./script1.py")

           if script2.collidepoint(pos):
              print ('execute script2.py')
              os.system("./script2.py")

           if script3.collidepoint(pos):
              print ('execute script3.py')
              os.system("./script3.py")

           if script4.collidepoint(pos):
              print ('execute script4.py')
              os.system("./script4.py")

           if load.collidepoint(pos):
              print ('load checkpoint')
              mc.postToChat("Checkpoint Loaded.")
              mc.restoreCheckpoint()

           if save.collidepoint(pos):
              print ('save checkpoint')
              mc.postToChat("Checkpoint Saved.")
              mc.saveCheckpoint()



           if bomb.collidepoint(pos):
              print ('Setting off random atomic bomb...')
              mc.postToChat("Random lava bomb dropped.")
              xran = random.randrange(-120,120+1)
              yran = random.randrange(-120,120+1)
              mc.setBlock(xran,30,yran,10)

           if flood.collidepoint(pos):
              print ('Setting off random storm...')
              mc.postToChat("Random storm somewhere.")
              xran = random.randrange(-120,120+1)
              yran = random.randrange(-120,120+1)
              mc.setBlock(xran,30,yran,8)


   screen.fill(WHITE)
   screen.blit(water_image,[190,5])
   screen.blit(waters_image,[215,5])
   screen.blit(lava_image,[240,5])
   screen.blit(lavas_image,[267,5])
   screen.blit(blank_image,[294,5])
   screen.blit(build_image,[350,5])
   screen.blit(up_image,[50,35])
   screen.blit(down_image,[50,62])
   screen.blit(left_image,[23,46])
   screen.blit(right_image,[77,46])
   screen.blit(up_image,[120,35])
   screen.blit(down_image,[120,62])
   screen.blit(digten_image,[152,35])
   screen.blit(digtwenty_image,[152,62])
   screen.blit(redtack_image,[182,35])
   screen.blit(reddest_image,[182,62])
   screen.blit(bluetack_image,[212,35])
   screen.blit(bluedest_image,[212,62])
   screen.blit(fixedcam_image,[242,35])
   screen.blit(standardcam_image,[242,62])
   screen.blit(script1_image,[272,35])
   screen.blit(script2_image,[272,62])
   screen.blit(script3_image,[302,35])
   screen.blit(script4_image,[302,62])
   screen.blit(load_image,[332,35])
   screen.blit(save_image,[332,62])
   screen.blit(bomb_image,[445,35])
   screen.blit(flood_image,[445,62])

   text = font.render("Set block under feet:",True,BLACK)

   block = "Block ID:"+str(KEYBLOCK)
   blockid = font.render(block,True,BLACK)
   screen.blit(text,[10,10])
   screen.blit(blockid,[380,10])
   pygame.display.flip()
   clock.tick(3)

pygame.quit()
