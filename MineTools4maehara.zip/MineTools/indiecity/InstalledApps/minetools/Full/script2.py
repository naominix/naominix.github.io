#!/usr/bin/python

import minecraft as minecraft
import block as block
import time as time
mc = minecraft.Minecraft.create()
mc.postToChat("Edit script2.py to do something!")


